# Indian-Sign-Language-Recognition
Indian Sign Language recognition for the disabled community using OpenCV and Tensorflow


Download the pre-trained model for this to work from here: [model.h5](https://mega.nz/file/MOYQyBID#wFT_LAklTT76Uj4OTzbfnucY9fJJgchHKsPNAzgc6Zg)
